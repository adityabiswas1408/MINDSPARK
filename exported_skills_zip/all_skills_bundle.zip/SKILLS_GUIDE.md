# Complete Skills Catalog & Execution Guide

This document indexes all **55 active skills** available in `.agents/skills`. Each entry provides the canonical skill name, a plain-English explanation of what it actually does, and concrete trigger scenarios for when to use it.

---

## Quick Navigation by Category

- [1. Planning, Ideation & Context Setup](#1-planning-ideation--context-setup) (6 skills)
- [2. Coding Standards, Architecture & Governance](#2-coding-standards-architecture--governance) (7 skills)
- [3. Simplicity & YAGNI (Ponytail Suite)](#3-simplicity--yagni-ponytail-suite) (4 skills)
- [4. Testing, Debugging, Verification & Takeover Recovery](#4-testing-debugging-verification--takeover-recovery) (6 skills)
- [5. Code Review & Meta-Quality](#5-code-review--meta-quality) (4 skills)
- [6. Frontend, UI & Visual Design](#6-frontend-ui--visual-design) (8 skills)
- [7. Agent Optimization & Memory](#7-agent-optimization--memory) (5 skills)
- [8. Document Automation, Media & API Tooling](#8-document-automation-media--api-tooling) (9 skills)

---

## 1. Planning, Ideation & Context Setup

### `brainstorming`
- **What it actually does:** An interactive dialogue workflow that explores product and feature ideas, evaluates tradeoffs, and produces design specs. Strictly enforces a hard gate requiring explicit human confirmation before writing code.
- **When to use it:**
  - Before starting any creative work, building new user-facing features, or adding functionality.
  - When you have a raw idea and need to clarify scope, UX, and technical approaches through collaborative dialogue.

### `clarifying-requests`
- **What it actually does:** A fast, lightweight triage questioning loop that takes vague, shallow, or one-liner requests, separates material unknowns from cosmetic ones, and asks batched targeted questions.
- **When to use it:**
  - When a user provides an underspecified prompt (*"help me with auth"*, *"improve this page"*, *"make it faster"*).
  - Before starting work on any task where multiple distinct interpretations are possible.

### `intent-driven-coding`
- **What it actually does:** Converts ambiguous feature requests, security updates, or database changes into concrete, testable acceptance criteria, explicit error-handling specs, and defined boundaries.
- **When to use it:**
  - When planning high-impact backend, database, security, or API changes.
  - When defining verifiable acceptance criteria or a definition of done for other developers or subagents.

### `blueprint`
- **What it actually does:** Turns a high-level goal into a phased construction plan for multi-session or multi-agent engineering projects with dependency graphs and PR boundaries.
- **When to use it:**
  - When planning large epic projects spanning multiple pull requests, multiple coding sessions, or complex refactors.
  - When coordinating parallel subagents or complex architecture roadmaps.

### `writing-plans`
- **What it actually does:** Writes a single-PR, bite-sized implementation plan assuming the developer has zero context. Maps out exact file modifications and task checklists saved to `docs/plans/YYYY-MM-DD-<feature>.md`.
- **When to use it:**
  - When you have a defined spec and want a detailed step-by-step execution roadmap before writing code.
  - For single-session or single-PR features where tasks must be broken into granular 2–5 minute steps.

### `mvp-context-kit`
- **What it actually does:** Sets up a minimal, fast 3-file agent context system for small projects, hackathons, weekend builds, or 30-day programs (`AGENTS.md`, `BUILD.md` checklist per feature, and `STATE.md`). Fully coordinated with `ponytail` (YAGNI ladder), `clarifying-requests` (entry triage), `systematic-debugging` (mid-build bug fixing), `full-output-enforcement` (zero truncated edits), and `context-budget` (graduation triggers).
- **When to use it:**
  - When starting something small and needing to move fast without bloated multi-file documentation.
  - For prototypes, hackathon apps, or student builds where speed is paramount.

---

## 2. Coding Standards, Architecture & Governance

### `project-context-system`
- **What it actually does:** Bootstraps and continuously maintains the full tiered agent-context documentation architecture for production/SaaS projects (`AGENTS.md`, `ARCHITECTURE.md`, `CONSTRAINTS.md`, `SECURITY.md`, `STATE.md`, `DECISIONS.md`, `TESTING.md`, `ROLLBACK.md`). Distinguishes doc-layer anti-bloat pruning (monitored via `context-budget`) from code-layer bloat scans (delegated to `ponytail-audit`). Integrates `intent-driven-coding`, `ponytail-debt`, and `ponytail-review`.
- **When to use it:**
  - When starting a production-grade SaaS codebase or scaling past MVP stage.
  - When AI agents keep losing context between sessions or need living, self-updating project memory.

### `karpathy-guidelines`
- **What it actually does:** Behavioral discipline inspired by Andrej Karpathy for coding models. Eliminates silent guesswork, premature abstraction, and drive-by rewrites across 4 core habits:
  1. *Surface assumptions, don't guess silently.*
  2. *Simplicity first (minimum code, zero speculative abstraction).*
  3. *Surgical changes (only touch lines tied to request, match existing style).*
  4. *Define success criteria, then loop (reproduce bugs first, executable verification).*
  Includes bundled reference examples in `references/examples.md`.
- **When to use it:**
  - On non-trivial feature work, bug fixes, refactors, and multi-file edits.
  - Whenever an unstated assumption could waste work or code invites unrelated "improvements."

### `architecture-decision-records`
- **What it actually does:** Spots when significant architectural choices are made (e.g. choosing a database, auth mechanism, or caching strategy) and captures them as structured ADRs in `docs/adr/YYYY-MM-DD-<title>.md`.
- **When to use it:**
  - When making high-impact technical choices, schema designs, or major refactors.
  - When you want a permanent record of *why* something was built a certain way.

### `codebase-onboarding`
- **What it actually does:** Systematically scans an unfamiliar codebase and generates an architecture map, a list of critical entry points, conventions, and starter agent instructions (`AGENTS.md` / `CLAUDE.md`).
- **When to use it:**
  - When exploring or joining a newly cloned repository for the first time.
  - When setting up AI coding assistant instructions in a repo that has none.

### `coding-standards`
- **What it actually does:** A language-agnostic clean code standard that enforces readable variable naming, immutability, pure functions, error-handling best practices, and anti-pattern prevention across stacks.
- **When to use it:**
  - When writing, refactoring, or reviewing code in JavaScript, TypeScript, Python, Go, Java, C++, or Rust.
  - When establishing baseline conventions for clean, maintainable software.

### `inherit-legacy-style`
- **What it actually does:** Analyzes an existing hand-written codebase across 4 dimensions (file anatomy, state control, utils structure, error habits) and records rules in `.ai-style-rules.md` to prevent the AI from drifting into generic pretrained habits.
- **When to use it:**
  - When introducing an AI coding assistant to a mature, legacy, or bespoke codebase.
  - When you want new AI-generated code to blend seamlessly with existing code idioms and avoid stylistic drift.

### `living-docs-governance`
- **What it actually does:** Prevents documentation from rotting by assigning documentation into 4 distinct roles: Constitution (rules), Map (locations & ownership), Status (blockers & delete-zone), and History (ADRs & reasons).
- **When to use it:**
  - In long-running projects when documentation is drifting from the code.
  - When deleted features or rejected approaches keep getting accidentally recreated.

---

## 3. Simplicity & YAGNI (Ponytail Suite)

### `ponytail`
- **What it actually does:** Channels a pragmatic senior dev who prevents over-engineering. Enforces the YAGNI decision ladder: *Does it need to exist? -> Codebase reuse -> Stdlib -> Native platform -> One-liner -> Minimum code*.
- **When to use it:**
  - On any coding task where you want the simplest, leanest solution with zero boilerplate.
  - Whenever you say *"be lazy"*, *"simplest solution"*, *"yagni"*, or complain about bloat.

### `ponytail-audit`
- **What it actually does:** Performs a whole-repository scan to find over-engineered abstractions, unused flexibility, speculative features, and custom code that can be deleted or replaced by standard library features.
- **When to use it:**
  - During codebase simplification, debt reduction, or refactoring sprints.
  - When asked *"what can we delete from this repo?"* or *"audit for over-engineering"*.

### `ponytail-debt`
- **What it actually does:** Scans the codebase for `# ponytail:` and `// ponytail:` comments to compile a single structured ledger tracking intentional shortcuts, their limitations, and when to upgrade them.
- **When to use it:**
  - When reviewing deliberate shortcuts taken during rapid development.
  - When checking what temporary simplifications exist before scaling up.

### `ponytail-review`
- **What it actually does:** Reviews code diffs and pull requests strictly for unnecessary complexity, unneeded abstractions, and third-party dependencies that should be replaced with simple native code.
- **When to use it:**
  - During code reviews when you want to ensure the submitted diff is as short and minimal as possible.
  - Tags findings as `delete:`, `stdlib:`, `native:`, `yagni:`, or `shrink:`.

---

## 4. Testing, Debugging, Verification & Takeover Recovery

### `project-takeover-recovery`
- **What it actually does:** A structured protocol for inheriting and fixing unfamiliar or broken codebases (student projects, freelance handovers, half-built apps) under an iron-clad scope contract (**0 features added, 0 features removed**, `.env` preservation, `full-output-enforcement` zero truncation rule, `ponytail` fix simplicity, `search-dependencies` vetting, and unified launch scripts).
- **When to use it:**
  - When taking over someone else's broken project (*"my friend's app is broken"*, *"fix and clean up this codebase"*).
  - When inheriting a half-done project that needs bug fixing and anti-AI-slop UI cleanup without scope creep.

### `systematic-debugging`
- **What it actually does:** Enforces a strict 4-phase root-cause debugging protocol (*Reproduce -> Trace Root Cause -> Minimal Fix -> Verify*) that forbids guessing or symptom-masking fixes. Includes condition-based waiting guides and test pollution finders.
- **When to use it:**
  - Whenever encountering any bug, test failure, crash, or unexpected behavior in code before attempting fixes.
  - When dealing with flaky tests, race conditions, or hard-to-reproduce errors.

### `tdd-workflow`
- **What it actually does:** A complete Test-Driven Development workflow enforcing the Iron Law (*"No production code without a failing test first"*), Red-Green-Refactor cycles, and comprehensive test design rules via `references/writing-good-tests.md` across Vitest, Jest, PyTest, Bun, and Playwright.
- **When to use it:**
  - When adding new features, fixing bugs, or refactoring code where automated tests must precede implementation.
  - When you need unit test design principles and test runner configurations.

### `verification-before-completion`
- **What it actually does:** An iron rule requiring the AI to run actual terminal verification commands (tests, builds, linters) and observe fresh passing output before claiming work is finished.
- **When to use it:**
  - Before claiming any task is done, creating pull requests, or asserting that tests pass.
  - Prevents premature or hallucinated "All tests passing!" claims.

### `search-dependencies`
- **What it actually does:** A "research before coding" protocol that forces searching for and vetting existing open-source libraries, CLI tools, or standard modules before writing custom solutions from scratch.
- **When to use it:**
  - Before implementing complex utilities (e.g. rate limiters, JWT parsers, csv exporters, retry loops).
  - When evaluating whether to install an external package or use built-in APIs.

### `deep-research`
- **What it actually does:** A multi-angle web research methodology that uses calibrated search depth, multiple queries, and full-content synthesis for complex questions, technical comparisons, and grounded reporting.
- **When to use it:**
  - For broad topics, technical comparisons ("X vs Y"), landscape analysis, and grounding content generation.
  - Avoid using for simple single-fact lookups (dates, single prices, etc.).

---

## 5. Code Review & Meta-Quality

### `receiving-code-review`
- **What it actually does:** Teaches the AI to evaluate human code review comments with technical rigor — verifying against codebase reality, pushing back on unsound advice, and applying fixes methodically without performative agreement.
- **When to use it:**
  - When feeding code review feedback, PR comments, or linter suggestions back into the agent for implementation.
  - Prevents blind, performative agreement (*"You're absolutely right!"*) with technically flawed review suggestions.

### `skill-creator`
- **What it actually does:** The master meta-skill for authoring, evaluating, optimizing, and benchmark-testing skills. Enforces structure guidelines, prevents under-triggering/over-triggering, and runs quality audits.
- **When to use it:**
  - When creating new skills from scratch or updating existing skills.
  - When auditing skill triggers, descriptions, or breaking large skills into progressive-disclosure references.

### `skill-stocktake`
- **What it actually does:** An auditing slash command and tool (`/skill-stocktake`) that scans installed skills, checks for overlap, audits quality, verifies technical currency, and maintains `results.json`.
- **When to use it:**
  - When organizing or pruning skills in `.agents/skills` or `~/.claude/skills`.
  - When reviewing duplicate skills, checking formatting, or auditing new additions.

### `full-output-enforcement`
- **What it actually does:** Overrides model truncation tendencies, bans lazy placeholders (`// ... rest of code`), and ensures full, complete code generation.
- **When to use it:**
  - When editing critical or large files where omitted lines would break the build.
  - When you require complete, drop-in replacement files without elisions.

---

## 6. Frontend, UI & Visual Design

### `design-taste-frontend`
- **What it actually does:** Master anti-slop frontend engineering directive built with progressive-disclosure references. Eliminates generic AI design defaults, enforces agency-level typography, calibrated palettes, micro-animations, double-bezel cards, and GSAP motion physics.
- **When to use it:**
  - When building modern landing pages, marketing sites, web apps, or component libraries that must look custom, polished, and expensive.
  - Core rules live in `SKILL.md`; specialized references live in `references/` (typography, motion, dark mode, patterns).

### `minimalist-ui`
- **What it actually does:** A clean, document-style UI design guide (Linear/Notion-inspired) with warm monochrome color schemes, flat bento grids, subtle pastel accents, and generous whitespace.
- **When to use it:**
  - When building clean SaaS productivity tools, document-based apps, or minimal developer portals.
  - When gradients, heavy drop shadows, and flashy animations are inappropriate.

### `industrial-brutalist-ui`
- **What it actually does:** A high-density, mechanical interface guide fusing Swiss typographic print with retro-futuristic aerospace and military terminal telemetry aesthetics.
- **When to use it:**
  - For developer tools, system monitoring consoles, cybersecurity dashboards, or brutalist creative portfolios.
  - When the interface needs to feel like a high-density, functional command center.

### `redesign-existing-projects`
- **What it actually does:** A 3-step audit (Scan, Diagnose, Fix) that upgrades an existing website's visual quality, spacing, and typography without breaking its existing architecture or rewriting everything from scratch. Supports 3 distinct design tiers:
  - **Tier 1 (Student/Bootcamp):** Clean, amateur, handcrafted feel (Inter/Outfit, simple grays, neat notebook feel, no AI slop, no enterprise overkill).
  - **Tier 2 (Professional SaaS):** Standard polished product design.
  - **Tier 3 (Premium Agency):** High-end interactive experience.
- **When to use it:**
  - When improving an existing, working website or app that looks dated or amateur.
  - When upgrading styling within the project's existing framework (Tailwind, CSS modules, Vanilla CSS).

### `image-to-code`
- **What it actually does:** A multimodal design-to-code process that generates or analyzes a reference design image, breaks it into distinct UI sections, and writes pixel-accurate frontend code matching the visual.
- **When to use it:**
  - When translating visual mockups, Figma screenshots, or generated reference images into responsive frontend code.
  - When you want visual fidelity checks between generated code and reference images.

### `imagegen-frontend-web`
- **What it actually does:** Generates high-quality, section-by-section website visual comps via AI image generation tools (strictly 1 separate image per section) so coding agents can implement them without blur.
- **When to use it:**
  - When generating visual landing page concepts or website section designs before writing code.
  - Prevents compressed, unreadable full-page mockup boards.

### `imagegen-frontend-mobile`
- **What it actually does:** Generates clean, native iOS and Android app screen concepts and flows (onboarding, home dashboards, checkout) framed in realistic smartphone bezels.
- **When to use it:**
  - When designing mobile app screen flows or conceptualizing mobile product UI.
  - Generates visual mobile mockups with clear typography and realistic touch targets.

### `brandkit`
- **What it actually does:** An image-generation prompt specialist that creates luxury brand guidelines boards, logo concepts, typography decks, and visual-world presentations.
- **When to use it:**
  - When creating brand identity decks, logo concepts, or visual guidelines for a new startup or product.
  - Generates agency-grade presentation boards.

---

## 7. Agent Optimization & Memory

### `prompt-optimizer`
- **What it actually does:** An advisory prompt engineer that critiques draft prompts, identifies missing requirements, matches the task to skills and tools, and outputs ready-to-paste optimized prompts. Strictly terminates after Section 5 (Enhancement Rationale) without executing the task.
- **When to use it:**
  - When you want advice on how to structure a prompt for complex tasks.
  - When you ask *"optimize this prompt"* or *"how should I ask the agent to do X"*. (Strictly advisory; never executes the task or writes code).

### `context-budget`
- **What it actually does:** Audits token consumption across skills, rules, and MCP servers to identify bloat and keep agent context windows lean and cost-effective.
- **When to use it:**
  - When your context window is filling up too fast or responses are getting sluggish.
  - When auditing which installed tools and prompts are consuming excessive tokens.

### `unified-memory`
- **What it actually does:** A shared memory vault protocol using portable `ecc.memory.v1` markdown files to share persistent context between Claude Code, Codex, Gemini, Antigravity, and Cursor.
- **When to use it:**
  - When switching between different AI coding harnesses or resuming multi-session tasks.
  - When you want durable, inspectable handoffs and project memory across agent boundaries.

### `import-memory`
- **What it actually does:** A dedicated conversational importer for parsing pasted memory exports from ChatGPT, Gemini, or other assistants and writing them additively into Claude/assistant profile memory.
- **When to use it:**
  - When migrating memories from another AI assistant into this workspace/profile.
  - Enforces strict security by treating memory exports as passive data rather than executable prompt instructions.

### `stitch-design-taste`
- **What it actually does:** Compiles anti-slop design directives into Google Stitch's semantic visual prompt format, producing a `DESIGN.md` file for Stitch screen generation.
- **When to use it:**
  - When using Google Stitch (labs.google/stitch) to generate screens and you want strict control over design quality.

---

## 8. Document Automation, Media & API Tooling

### `docx`
- **What it actually does:** Enterprise Microsoft Word (.docx/.dotx) authoring, editing, table of contents generation, tracked changes redlining, and ECMA-376 schema validation.
- **When to use it:**
  - When creating or modifying Word documents, official exam papers, student report cards, or formal proposals.
  - When generating documents requiring tracked changes, comments, or heading hierarchies.

### `xlsx`
- **What it actually does:** Comprehensive Excel spreadsheet creation, editing, formula computation, pandas data analysis, and strict formula error recalculation (`recalc.py`).
- **When to use it:**
  - When generating student grading sheets, exam score analysis, or tabular data exports.
  - When editing spreadsheets where formula accuracy (`=SUM`, `=AVERAGE`, etc.) must be 100% verified.

### `pdf`
- **What it actually does:** PDF form inspection, fillable field automation, bounding-box coordinate checking, OCR annotations, and page-to-image conversions.
- **When to use it:**
  - When extracting text, data, or tables from PDF documents.
  - When filling out official PDF certificates, forms, or checking layout bounding boxes.

### `pptx`
- **What it actually does:** PowerPoint presentation deck generation, slide layout templating, chart embedding, and PresentationML schema validation.
- **When to use it:**
  - When generating pitch decks, teacher training slides, or competition overview presentations.

### `claude-api`
- **What it actually does:** Deep multi-language reference library for prompt caching, token counting, tool use definitions, and streaming architectures across TypeScript, Python, and cURL.
- **When to use it:**
  - When integrating AI agent endpoints, LLM-based student feedback, or grading assistants.

### `canvas-design`
- **What it actually does:** Visual layout principles for poster and certificate design, packaged with 54 production-grade open-source OFL font families.
- **When to use it:**
  - When designing high-impact printable certificates, posters, or typography-heavy assets.

### `internal-comms`
- **What it actually does:** Standardized templates for engineering status reports, incident postmortems, leadership briefings, and company newsletters.
- **When to use it:**
  - When drafting formal internal communications or executive summaries.

### `algorithmic-art`
- **What it actually does:** Interactive generative art, flow fields, and mathematical curves rendered using p5.js.
- **When to use it:**
  - When creating generative geometry, interactive math visualizers, or background canvas animations.

### `slack-gif-creator`
- **What it actually does:** Programmatic animated GIF generation with frame easing, color quantization, and Slack dimensions.
- **When to use it:**
  - When creating animated reaction GIFs or step-by-step visual calculation demonstrations.
