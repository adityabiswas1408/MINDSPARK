# AI Agent Skills Manifest & Intent Execution Engine

> **TARGET AUDIENCE: AI Coding Agents, LLMs, Subagents, and Autonomous Chains.**
> This manifest is a machine-oriented operational specification for all **55 skills** located in `.agents/skills/`.
> Use this document to resolve user intent, determine trigger validity, enforce hard execution gates, manage input/output contracts, and orchestrate multi-skill execution chains without hallucination.

---

## 1. Global AI Execution Rules & Hard Invariants

1. **Pre-Execution Gate:** If a skill defines a `<HARD-GATE>` or user approval requirement (e.g., `brainstorming`, `writing-plans`, `architecture-decision-records`), the agent **MUST NOT** modify files or execute code before explicit user sign-off.
2. **Terminal Evidence Gate:** Work is never claimed "done" or "passing" based on reasoning alone. The agent **MUST** run the actual command and inspect live terminal output per `verification-before-completion`.
3. **The Iron Law of TDD:** No production code without a failing test first (`tdd-workflow`).
4. **Behavioral Discipline & Surgical Diffs:** Surface assumptions rather than silently guessing; touch only requested lines (`karpathy-guidelines`).
5. **Strict Scope Lock on Takeovers:** When inheriting unfamiliar or broken projects (`project-takeover-recovery`), enforce **zero features added, zero features removed**, zero credential loss (`.env` preservation), zero elided/truncated code (`full-output-enforcement`), and use `ponytail` for fix simplicity (stdlib/repo utils before new deps).
6. **Tiered Context Discipline:** Small builds use lightweight context (`mvp-context-kit`) leaning on `ponytail` YAGNI ladder by default; production systems use tiered memory (`project-context-system`) with doc-level pruning monitored by `context-budget` and periodic `ponytail-audit` passes.
7. **Immutability & Zero Placeholder Rule:** Never emit partial snippets, `// ... rest of code`, or untested mocks when modifying production files (`full-output-enforcement`).
8. **Minimalism Hierarchy (YAGNI):** Standard library > Existing repo utils > Native platform features > Minimal custom logic > Third-party dependencies (`ponytail`).

---

## 2. Global Skill Routing & Orchestration Matrix

### Primary Workflow Chains

```mermaid
graph TD
    UserRequest([User Request / Prompt]) --> Triage{Triage & Ambiguity Check}
    
    %% Triage & Onboarding
    Triage -->|Vague / Shallow Ask| CR[clarifying-requests]
    Triage -->|Unfamiliar Repo / Fresh Clone| CO[codebase-onboarding]
    Triage -->|Legacy / Handcrafted Repo| ILS[inherit-legacy-style]
    Triage -->|Inherited / Broken Codebase| PTR[project-takeover-recovery]
    Triage -->|Deep Multi-Angle Topic Search| DR[deep-research]
    Triage -->|ChatGPT/Gemini Memory Import| IM[import-memory]
    
    %% Context & Docs Setup
    Triage -->|Fast MVP / Hackathon Setup| MVP[mvp-context-kit]
    Triage -->|Production SaaS Context System| PCS[project-context-system]
    
    %% Planning & Design
    CR --> Intent{Task Intent}
    CO --> Intent
    ILS --> Intent
    DR --> Intent
    
    Intent -->|New Feature / Creative Idea| BS[brainstorming]
    Intent -->|High-Impact Backend / DB Spec| IDC[intent-driven-coding]
    Intent -->|Multi-Session Epic / Multi-PR| BP[blueprint]
    Intent -->|Single PR / Granular Plan| WP[writing-plans]
    
    %% UI Design Paths
    Intent -->|Landing / Marketing Page| DTF[design-taste-frontend]
    Intent -->|Clean / Document / SaaS UI| MUI[minimalist-ui]
    Intent -->|High-Density / Terminal / Data| IBU[industrial-brutalist-ui]
    Intent -->|Existing App Upgrade / Student UI| RE[redesign-existing-projects]
    Intent -->|Mockup / Image to Code| ITC[image-to-code]
    
    %% Architecture & Decisions
    BS -->|Major Arch Choice| ADR[architecture-decision-records]
    IDC --> ADR
    BP --> ADR
    
    %% Implementation & Coding
    BS -->|Spec Approved| WP
    IDC -->|Criteria Set| WP
    WP --> KG[karpathy-guidelines]
    KG --> TDD[tdd-workflow]
    BP --> TDD
    
    %% Debugging & Takeover
    Intent -->|Bug / Test Failure / Crash| SD[systematic-debugging]
    PTR --> SD
    SD --> TDD
    
    %% Review & Quality Gates
    TDD --> PR[ponytail-review]
    PR --> CS[coding-standards]
    CS --> FOE[full-output-enforcement]
    FOE --> VBC[verification-before-completion]
    VBC --> Complete([Task Completed & Verified])
```

---

## 3. Disambiguation & Conflict Resolution Matrix

| Ambiguity | Preferred Skill | Reject / Route Away | Reason |
| :--- | :--- | :--- | :--- |
| **Fast Prototype vs Production Context System** | `mvp-context-kit` | `project-context-system` | If building a hackathon, quick prototype, or 30-day build, use `mvp-context-kit` (<3 files) with `ponytail` YAGNI discipline. Only use `project-context-system` for scaled SaaS, multi-service, or production apps. |
| **Inherited / Broken Codebase Takeover** | `project-takeover-recovery` | `codebase-onboarding` alone | If handed someone else's broken app with a "fix-only" mandate, use `project-takeover-recovery` to enforce scope-lock, `.env` protection, `ponytail` fix simplicity, `full-output-enforcement` and start scripts. |
| **Vague prompt vs New Feature Design** | `clarifying-requests` | `brainstorming` | If the ask is a 1-liner with material unknowns, clarify first. Only switch to `brainstorming` once the general direction is bounded. |
| **Single-PR Plan vs Multi-PR Epic** | `writing-plans` | `blueprint` | Use `writing-plans` for immediate single-PR tasks (2-5 min steps). Use `blueprint` only for multi-session, multi-PR architecture roadmaps. |
| **Code Library Search vs Topic Web Research** | `search-dependencies` | `deep-research` | `search-dependencies` checks npm/PyPI/GitHub before writing code. `deep-research` conducts multi-angle web research for domain knowledge or articles. |
| **External Memory Import vs Cross-Harness Memory Vault** | `import-memory` | `unified-memory` | `import-memory` parses ChatGPT/Gemini memory exports for assistant profile memory. `unified-memory` handles repo-level `.ecc/memory/` vault files. |
| **Coding Discipline vs General Code Standards** | `karpathy-guidelines` | `coding-standards` | `karpathy-guidelines` enforces surgical diffs, explicit assumptions, and anti-guesswork habits. `coding-standards` enforces naming, pure functions, and immutability. |
| **General UI vs Minimalist/Document UI** | `minimalist-ui` | `design-taste-frontend` | If user asks for Notion/Linear calm, document-style, or monochrome UI, use `minimalist-ui`. If user wants marketing, motion, or Awwwards feel, use `design-taste-frontend`. |
| **Student/Amateur UI vs Pro SaaS** | `redesign-existing-projects` (Tier 1) | `design-taste-frontend` | If the brief is a student bootcamp project or amateur portfolio, choose Tier 1 in `redesign-existing-projects`. Avoid agency-level over-engineering. |
| **Diff Review vs Repo-wide Bloat Scan** | `ponytail-review` | `ponytail-audit` | `ponytail-review` inspects a PR or pending diff. `ponytail-audit` scans the entire repository tree. |

---

## 4. Comprehensive Skill Specifications (40 Skills)

```
================================================================================
CATEGORY 1: PLANNING, IDEATION & CONTEXT SETUP (6 Skills)
================================================================================
```

### 1. `brainstorming`
- **Canonical Path:** `.agents/skills/brainstorming/SKILL.md`
- **Semantic Intent:** Socratic dialogue to explore ideas, evaluate tradeoffs, and write specifications before implementation.
- **Hard Gate:** **HALT BEFORE WRITING CODE.** Do not touch source files until user approves design spec.
- **Input / Output:** Input: User concept. Output: `docs/specs/YYYY-MM-DD-<topic>-design.md`.

### 2. `clarifying-requests`
- **Canonical Path:** `.agents/skills/clarifying-requests/SKILL.md`
- **Semantic Intent:** Rapid front-door triage that extracts material vs. cosmetic unknowns from vague prompts, asking 1–3 focused questions in a single batch.
- **Positive Triggers:** Vague one-liners ("help me with auth", "make this faster", "improve my site").

### 3. `intent-driven-coding`
- **Canonical Path:** `.agents/skills/intent-driven-coding/SKILL.md`
- **Semantic Intent:** De-risks ambiguous or high-impact engineering changes by formalizing verifiable acceptance criteria and explicit edge cases.

### 4. `blueprint`
- **Canonical Path:** `.agents/skills/blueprint/SKILL.md`
- **Semantic Intent:** Generates cold-executable, multi-session construction plans broken into discrete PR-sized steps with dependency graphs.

### 5. `writing-plans`
- **Canonical Path:** `.agents/skills/writing-plans/SKILL.md`
- **Semantic Intent:** Authors an exhaustive, bite-sized implementation plan assuming zero prior context. Every step is 2–5 minutes of action.
- **Hard Gate:** Zero placeholders ("TBD", "TODO", "implement later" are banned).

### 6. `mvp-context-kit`
- **Canonical Path:** `.agents/skills/mvp-context-kit/SKILL.md`
- **Semantic Intent:** Ultra-lean, fast agent context setup for hackathons, weekend builds, prototypes, or 30-day programs. Uses a 1-file `AGENTS.md`, a per-feature `BUILD.md` checklist, and a 2-line `STATE.md`.
- **Ecosystem Coordination:**
  - Integrates `ponytail`'s YAGNI ladder by default.
  - Integrates `clarifying-requests` for fast entry-point triage.
  - Integrates `systematic-debugging` if features break mid-build.
  - Integrates `full-output-enforcement` and `verification-before-completion` before closing tasks.
  - Uses `context-budget` to trigger migration when docs grow past single-file limits.
- **Positive Triggers:** "Quick prototype", "hackathon build", "MVP", "30-day build", "just get me going fast without 10 doc files".

```
================================================================================
CATEGORY 2: CODING STANDARDS, ARCHITECTURE & GOVERNANCE (7 Skills)
================================================================================
```

### 7. `project-context-system`
- **Canonical Path:** `.agents/skills/project-context-system/SKILL.md`
- **Reference Files:** `references/file-templates.md`
- **Semantic Intent:** Bootstraps and maintains the full tiered agent-context engineering system for production/SaaS projects (`AGENTS.md`, `ARCHITECTURE.md`, `CONSTRAINTS.md`, `SECURITY.md`, `STATE.md`, `DECISIONS.md`, `TESTING.md`, `ROLLBACK.md`).
- **Ecosystem Coordination:**
  - Uses `context-budget` to monitor actual token loads against the ~100-line budget.
  - Integrates `intent-driven-coding` for Phase 2 feature specs.
  - Uses `ponytail-debt` to prevent duplicate shortcut tracking.
  - Runs `ponytail-review` on diffs before shipping features, and periodic `ponytail-audit` passes.
- **Positive Triggers:** Starting serious production projects, "give this project an agent memory system", retrofitting living documentation.

### 8. `karpathy-guidelines`
- **Canonical Path:** `.agents/skills/karpathy-guidelines/SKILL.md`
- **Reference Files:** `references/examples.md`
- **Semantic Intent:** Core behavioral discipline inspired by Andrej Karpathy: surface assumptions, simplicity first, surgical diffs, and verifiable success criteria.
- **Key Invariants:** Reproduce before fixing; never silently refactor adjacent code; executable proof over claims.

### 9. `architecture-decision-records`
- **Canonical Path:** `.agents/skills/architecture-decision-records/SKILL.md`
- **Semantic Intent:** Automatically detects architectural decision moments and documents them as lightweight Michael Nygard-format ADRs in `docs/adr/`.

### 10. `codebase-onboarding`
- **Canonical Path:** `.agents/skills/codebase-onboarding/SKILL.md`
- **Semantic Intent:** Performs structured reconnaissance on an unfamiliar repository, creating an architectural map, entry points guide, and starter `AGENTS.md` / `CLAUDE.md`.

### 11. `coding-standards`
- **Canonical Path:** `.agents/skills/coding-standards/SKILL.md`
- **Semantic Intent:** Cross-language baseline for descriptive naming, immutability, pure functions, AAA test structure, and code-smell elimination.

### 12. `inherit-legacy-style`
- **Canonical Path:** `.agents/skills/inherit-legacy-style/SKILL.md`
- **Semantic Intent:** Scans legacy or handcrafted code across 4 dimensions (file anatomy, state control, utils structure, error habits) to prevent AI style drift.

### 13. `living-docs-governance`
- **Canonical Path:** `.agents/skills/living-docs-governance/SKILL.md`
- **Semantic Intent:** Establishes a 4-role documentation taxonomy (Constitution, Map, Status, History) to prevent doc rot and zombie feature resurrection.

```
================================================================================
CATEGORY 3: SIMPLICITY & YAGNI (PONYTAIL SUITE) (4 Skills)
================================================================================
```

### 14. `ponytail`
- **Canonical Path:** `.agents/skills/ponytail/SKILL.md`
- **Semantic Intent:** Senior developer persona enforcing strict YAGNI ladder: Stdlib -> Native Platform -> One-Liner -> Minimal Code.

### 15. `ponytail-audit`
- **Canonical Path:** `.agents/skills/ponytail-audit/SKILL.md`
- **Semantic Intent:** Whole-repo static analysis identifying over-engineered abstractions, unused wrappers, single-caller layers, and redundant libraries.

### 16. `ponytail-debt`
- **Canonical Path:** `.agents/skills/ponytail-debt/SKILL.md`
- **Semantic Intent:** Harvests all `// ponytail:` or `# ponytail:` comments into a structured debt ledger.

### 17. `ponytail-review`
- **Canonical Path:** `.agents/skills/ponytail-review/SKILL.md`
- **Semantic Intent:** Reviews pull requests or code diffs exclusively for complexity bloat and speculative generalization.

```
================================================================================
CATEGORY 4: TESTING, DEBUGGING, VERIFICATION & TAKEOVER RECOVERY (6 Skills)
================================================================================
```

### 18. `project-takeover-recovery`
- **Canonical Path:** `.agents/skills/project-takeover-recovery/SKILL.md`
- **Reference Files:** `references/example-takeover-brief.md`
- **Semantic Intent:** Protocol for inheriting, diagnosing, and fixing unfamiliar or broken codebases (student projects, freelance handovers, half-built apps) under a strict scope lock.
- **Positive Triggers:** "My friend's project is broken", "take over this codebase", "fix and clean up this half-done app", "UI looks AI-generated, clean it up".
- **Hard Non-Negotiables:**
  - **Scope Lock:** 0 features added, 0 features removed (enforced via `FEATURE-AUDIT.md`).
  - **Zero Credential Loss:** Diffing `.env` before and after session.
  - **Single Launch Script:** Builds/tests `start-server.bat` or `start.sh`.
  - **Zero Truncation Rule:** Strict `full-output-enforcement` for every edit on inherited code.
  - **Minimalism & Vetting:** Uses `ponytail` for fix simplicity, `ponytail-audit` for optional bloat recon, `search-dependencies` if a dependency is truly unavoidable, and `ponytail-review` before handover.

### 19. `systematic-debugging`
- **Canonical Path:** `.agents/skills/systematic-debugging/SKILL.md`
- **Reference Files:** `condition-based-waiting.md`, `defense-in-depth.md`, `root-cause-tracing.md`
- **Semantic Intent:** 4-Phase bug resolution protocol: Reproduce -> Trace Root Cause -> Minimal Fix -> Verify.

### 20. `tdd-workflow`
- **Canonical Path:** `.agents/skills/tdd-workflow/SKILL.md`
- **Reference Files:** `references/writing-good-tests.md`
- **Semantic Intent:** Enforces Test-Driven Development (RED -> GREEN -> REFACTOR) targeting 80%+ test coverage.
- **The Iron Law:** **NO PRODUCTION CODE WITHOUT A FAILING TEST FIRST.**

### 21. `verification-before-completion`
- **Canonical Path:** `.agents/skills/verification-before-completion/SKILL.md`
- **Semantic Intent:** Mandatory pre-completion barrier that forbids declaring success without terminal command evidence.

### 22. `search-dependencies`
- **Canonical Path:** `.agents/skills/search-dependencies/SKILL.md`
- **Semantic Intent:** Research-before-coding protocol that evaluates existing open-source libraries before building custom solutions.

### 23. `deep-research`
- **Canonical Path:** `.agents/skills/deep-research/SKILL.md`
- **Semantic Intent:** Systematic multi-pass web research methodology for in-depth technical comparisons, landscape analysis, and domain reports.

```
================================================================================
CATEGORY 5: CODE REVIEW & META-QUALITY (4 Skills)
================================================================================
```

### 24. `receiving-code-review`
- **Canonical Path:** `.agents/skills/receiving-code-review/SKILL.md`
- **Semantic Intent:** Governs how an AI agent processes human code review comments with technical rigor without performative agreement.

### 25. `skill-creator`
- **Canonical Path:** `.agents/skills/skill-creator/SKILL.md`
- **Semantic Intent:** Authoring, benchmarking, and trigger-optimization engine for Claude/Gemini skills.

### 26. `skill-stocktake`
- **Canonical Path:** `.agents/skills/skill-stocktake/SKILL.md`
- **Semantic Intent:** Auditing tool that scans installed skills, checks for overlap, audits quality, and maintains `results.json`.

### 27. `full-output-enforcement`
- **Canonical Path:** `.agents/skills/full-output-enforcement/SKILL.md`
- **Semantic Intent:** Behavioral override that bans code elisions, truncation, or laziness in code output.

```
================================================================================
CATEGORY 6: FRONTEND, UI & VISUAL DESIGN (8 Skills)
================================================================================
```

### 28. `design-taste-frontend`
- **Canonical Path:** `.agents/skills/design-taste-frontend/SKILL.md`
- **Reference Files:** `references/typography-and-color.md`, `references/motion-and-layout.md`, `references/dark-mode-and-redesign.md`, `references/patterns-and-appendices.md`
- **Semantic Intent:** Master anti-slop frontend engineering directive. Enforces the 3 Dials (`DESIGN_VARIANCE`, `MOTION_INTENSITY`, `VISUAL_DENSITY`), bans AI default aesthetics, and enforces responsive viewport hygiene.

### 29. `minimalist-ui`
- **Canonical Path:** `.agents/skills/minimalist-ui/SKILL.md`
- **Semantic Intent:** Clean, document-style UI framework inspired by Linear and Notion (monochrome palettes, flat bento grids, zero drop shadows).

### 30. `industrial-brutalist-ui`
- **Canonical Path:** `.agents/skills/industrial-brutalist-ui/SKILL.md`
- **Semantic Intent:** High-density mechanical interface design fusing Swiss typographic print with aerospace telemetry and military terminal aesthetics.

### 31. `redesign-existing-projects`
- **Canonical Path:** `.agents/skills/redesign-existing-projects/SKILL.md`
- **Semantic Intent:** Upgrades existing web projects through a 3-step audit (Scan -> Diagnose -> Fix) supporting 3 tiers: Tier 1 (Student/Bootcamp), Tier 2 (Pro SaaS), Tier 3 (Premium Agency).

### 32. `image-to-code`
- **Canonical Path:** `.agents/skills/image-to-code/SKILL.md`
- **Semantic Intent:** Multimodal design translation protocol that generates/analyzes UI reference images and produces pixel-accurate responsive frontend code.

### 33. `imagegen-frontend-web`
- **Canonical Path:** `.agents/skills/imagegen-frontend-web/SKILL.md`
- **Semantic Intent:** Section-by-section website image prompt generator (strictly 1 separate image per page section).

### 34. `imagegen-frontend-mobile`
- **Canonical Path:** `.agents/skills/imagegen-frontend-mobile/SKILL.md`
- **Semantic Intent:** Mobile app screen concept generator that produces native iOS and Android flows framed within smartphone bezels.

### 35. `brandkit`
- **Canonical Path:** `.agents/skills/brandkit/SKILL.md`
- **Semantic Intent:** Visual identity prompt specialist for generating luxury brand guidelines, logo systems, typography boards, and identity decks.

```
================================================================================
CATEGORY 7: AGENT OPTIMIZATION & MEMORY (5 Skills)
================================================================================
```

### 36. `prompt-optimizer`
- **Canonical Path:** `.agents/skills/prompt-optimizer/SKILL.md`
- **Semantic Intent:** Advisory prompt engineer that analyzes prompt weaknesses, dynamically inspects workspace skills, and generates optimized prompts.
- **Hard Gate:** **STRICT ADVISORY HALT.** Must NEVER execute the draft task or generate the prompt's underlying deliverable. Output must terminate immediately after Section 5 (Enhancement Rationale).
- **Positive Triggers:** "Optimize prompt", "improve my prompt", "what skill to use with this prompt", "recommend skills for prompt".

### 37. `context-budget`
- **Canonical Path:** `.agents/skills/context-budget/SKILL.md`
- **Semantic Intent:** Diagnostic skill that measures token consumption across agents, skills, and tools, pinpointing context bloat.

### 38. `unified-memory`
- **Canonical Path:** `.agents/skills/unified-memory/SKILL.md`
- **Semantic Intent:** Cross-agent durable memory protocol storing context in portable `ecc.memory.v1` format.

### 39. `import-memory`
- **Canonical Path:** `.agents/skills/import-memory/SKILL.md`
- **Semantic Intent:** Dedicated conversational importer for parsing pasted memory exports from ChatGPT, Gemini, or other assistants safely into profile memory.

### 40. `stitch-design-taste`
- **Canonical Path:** `.agents/skills/stitch-design-taste/SKILL.md`
- **Semantic Intent:** Generates semantic `DESIGN.md` guidelines tailored specifically for Google Stitch screen generation.

```
================================================================================
CATEGORY 8: DOCUMENT AUTOMATION, MEDIA & API TOOLING (9 Skills)
================================================================================
```

### 41. `docx`
- **Canonical Path:** `.agents/skills/docx/SKILL.md`
- **Semantic Intent:** Enterprise Word document (.docx/.dotx) authoring, editing, table of contents formatting, tracked changes redlining, and ECMA-376 schema validation.
- **Positive Triggers:** "Generate Word doc", "create .docx report", "edit document with track changes", "official printable exam paper".

### 42. `xlsx`
- **Canonical Path:** `.agents/skills/xlsx/SKILL.md`
- **Semantic Intent:** Spreadsheet (.xlsx/.xlsm) creation, formulas, pandas data pipelines, and strict formula recalculation with zero error tolerance (`recalc.py`).
- **Positive Triggers:** "Create Excel sheet", "calculate student grades .xlsx", "import spreadsheet marks", "fix excel formulas".

### 43. `pdf`
- **Canonical Path:** `.agents/skills/pdf/SKILL.md`
- **Semantic Intent:** PDF form inspection, fillable field automation, bounding-box coordinate checks, OCR annotations, and page conversions.
- **Positive Triggers:** "Fill PDF form", "extract text from PDF", "inspect PDF layout", "convert PDF pages to images".

### 44. `pptx`
- **Canonical Path:** `.agents/skills/pptx/SKILL.md`
- **Semantic Intent:** PowerPoint presentation deck generation, slide layout templating, chart embedding, and PresentationML schema validation.
- **Positive Triggers:** "Create slide deck", "presentation .pptx", "competition pitch slides".

### 45. `claude-api`
- **Canonical Path:** `.agents/skills/claude-api/SKILL.md`
- **Semantic Intent:** Comprehensive multi-language API reference for prompt caching, token counting, tool use definitions, and streaming architectures across TypeScript, Python, and cURL.
- **Positive Triggers:** "How to use prompt caching", "Claude API token counting", "tool-calling schema reference".

### 46. `canvas-design`
- **Canonical Path:** `.agents/skills/canvas-design/SKILL.md`
- **Semantic Intent:** Visual layout principles for poster and certificate design, packaged with 54 production-grade open-source OFL font families.
- **Positive Triggers:** "Design certificate poster", "render high-res visual art", "typography layout".

### 47. `internal-comms`
- **Canonical Path:** `.agents/skills/internal-comms/SKILL.md`
- **Semantic Intent:** Structured templates for engineering status reports, incident postmortems, leadership briefings, and company newsletters.
- **Positive Triggers:** "Draft status report", "write postmortem", "internal stakeholder update".

### 48. `algorithmic-art`
- **Canonical Path:** `.agents/skills/algorithmic-art/SKILL.md`
- **Semantic Intent:** Interactive generative art, flow fields, and mathematical curves rendered using p5.js.
- **Positive Triggers:** "Generate p5.js art", "math visualization curve", "generative particle flow".

### 49. `slack-gif-creator`
- **Canonical Path:** `.agents/skills/slack-gif-creator/SKILL.md`
- **Semantic Intent:** Programmatic animated GIF generation with frame easing, color quantization, and Slack dimensions.
- **Positive Triggers:** "Create animated GIF", "render step-by-step animation".

---

## 5. Summary Table of Artifacts Produced by Skills

| Artifact File Path | Producing Skill | Purpose |
| :--- | :--- | :--- |
| `docs/specs/YYYY-MM-DD-<topic>-design.md` | `brainstorming` | Validated feature design specification |
| `docs/plans/YYYY-MM-DD-<feature>.md` | `writing-plans` | Bite-sized single-PR implementation roadmap |
| `plans/<name>.md` | `blueprint` | Multi-session / multi-agent epic construction plan |
| `RECON.md` & `FEATURE-AUDIT.md` | `project-takeover-recovery` | Codebase inventory and feature audit table |
| `HANDOVER.md` | `project-takeover-recovery` | Final verified handover and environment summary |
| `ARCHITECTURE.md` / `CONSTRAINTS.md` / `SECURITY.md` | `project-context-system` | Foundational production context layer |
| `STATE.md` (root) | `project-context-system` / `mvp-context-kit` | Living session state tracker (rewritten each session) |
| `BUILD.md` (root or `docs/build/`) | `mvp-context-kit` | Fast per-feature checklist and verification criterion |
| `docs/adr/NNNN-<decision-title>.md` | `architecture-decision-records` | Architectural Decision Record |
| `docs/adr/README.md` | `architecture-decision-records` | Chronological ADR index table |
| `.ai-style-rules.md` | `inherit-legacy-style` | Machine-readable style rules for legacy codebase |
| `AGENTS.md` / `CLAUDE.md` | `codebase-onboarding` | Master harness instruction entry points |
| `docs/testing/<task>.tdd.md` | `tdd-workflow` | TDD evidence and validation report |
| `DESIGN.md` | `stitch-design-taste` | Visual design prompt contract for Google Stitch |
